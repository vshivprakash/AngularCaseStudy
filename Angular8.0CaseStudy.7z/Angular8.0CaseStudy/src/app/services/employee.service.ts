import { Injectable } from '@angular/core';
import { Employee } from '../models/employee.model';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  employees:Employee[] = [
  {
    id:1,
    name:"Prakash",
    email:"test@test.com",
    phone:111
  },
  {
    id:2,
    name:"Kumar",
    email:"test@test.com",
    phone:112
  }
  ]

  //apiURL='assets/data/employees.json';
 // employees:Employee[]=[];

  /*getEmpList(){
  this.http.get<Employee[]>(this.apiURL).subscribe(
    (response)=>
    {
      this.employees = response;
    },
    (error) => console.log(error)
  );
 }
  //employees=this.http.get(this.apiURL);*/

  constructor(public http:HttpClient) { }

  onGet(){
    //this.getEmpList();
    return this.employees;
  }
  onAdd(employee:Employee){

    this.employees.push(employee);

  }

  onDelete(id:number){
    let employee;
     employee = this.employees.find(x=>x.id===id);
    let index=this.employees.indexOf(employee,0);
    this.employees.splice(index,1);

  }

  onGetEmployee(id:number){
    return this.employees.find(x=>x.id===id);

  }
  onUpdate(employee:Employee){
   let oldEmployee = this.employees.find(x=>x.id === employee.id);
    oldEmployee.name=employee.name;
    oldEmployee.email=employee.email;
    oldEmployee.phone=employee.phone;


  }
}
