import { Injectable } from '@angular/core';
import{HttpClient}from '@angular/common/http';
import{Employees} from'./Employees';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  constructor(private http : HttpClient) { }

  url:string="http://localhost:3000/Employees";

  getEmployeeList(){
    return this.http.get<Employees[]>(this.url);
  }

}

