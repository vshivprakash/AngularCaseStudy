import { Component, OnInit } from '@angular/core';
import {EmployeeService} from'./employee.service';
import { Employees } from './Employees';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  constructor(private empService:EmployeeService){}
  columns = ["User Id","First Name","Last Name", "Email", "Mobile", "Salary"];
  row:string[] = ["empId", "firstName", "lastName", "email", "mobile", "salary"];
  employees:Employees[]=[];
  ngOnInit(): void {
    localStorage.setItem('userAccessEnabled','false');
    this.empService.getEmployeeList().subscribe
     (
       (response)=>
       {
         this.employees = response;
       },
       (error) => console.log(error)
     )
  }
  title = 'EmployeeCRUD';
}
