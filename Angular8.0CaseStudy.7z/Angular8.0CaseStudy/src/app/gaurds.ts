import { Injectable } from "@angular/core";
import { ActivatedRoute, ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot } from "@angular/router";

@Injectable({
  providedIn:'root'
})
export class CanActivateClass implements CanActivate{

  canActivate(route:ActivatedRouteSnapshot,state:RouterStateSnapshot):boolean{
    let access=localStorage.getItem('userAccessEnabled');
    //if(access=="true"){ return true} else{
    return true;
   // }
  }
}
