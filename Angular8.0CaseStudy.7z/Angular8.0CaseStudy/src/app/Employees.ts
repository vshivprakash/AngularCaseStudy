export class Employees
{
    empId:string;
    firstName:string;
    lastName:string;
    email:string;
    mobile:string;
    salary:string;


    constructor(empId: string,firstName: string, lastName: string, email: string, mobile: string, salary: string)
    {
        this.empId = empId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.mobile = mobile;
        this.salary = salary;
    }


}
